# AI Agent Testing Framework

Test AI agent performance with hotel reservation management tools.

**Tasks**: 3 coding tasks focused on agent evaluation and validation.

**Goal**: Build test cases that validate AI agent behavior with MCP tools.

**Deliverable**: Zip archive with implemented solutions. 