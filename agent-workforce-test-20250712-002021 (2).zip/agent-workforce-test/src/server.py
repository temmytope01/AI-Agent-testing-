"""
FastMCP server entry point.
"""
from .reservation_server import main

if __name__ == "__main__":
    main() 